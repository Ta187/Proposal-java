
package proposal;
import java.util.Scanner;
public class Proposal {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);

      System.out.print("Did the guy come with a flower? (yes/no): ");
        String hasFlower = scanner.next().trim().toLowerCase();

        System.out.print("Did the guy come with a diamond ring? (yes/no): ");
        String hasDiamondRing = scanner.next().trim().toLowerCase();

        System.out.print("Enter the number of times the crowd shouted ' SAY YES': ");
        int crowdShoutedYes = scanner.nextInt();

        scanner.close();

    
        boolean flowerCondition = hasFlower.equals("yes");
        boolean diamondRingCondition = hasDiamondRing.equals("yes");
        boolean crowdCondition = (crowdShoutedYes >= 30);

        if (flowerCondition && diamondRingCondition && crowdCondition) {
            System.out.println("Lady Response: YES");
        } else {
            System.out.println("Lady Response: NO");
               
      }
         scanner.close();
         
    }
    
    }
